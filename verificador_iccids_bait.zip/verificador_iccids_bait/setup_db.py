from supabase import create_client
import os
from dotenv import load_dotenv

load_dotenv()

supabase_url = os.getenv("SUPABASE_URL")
supabase_key = os.getenv("SUPABASE_SERVICE_KEY")

supabase = create_client(supabase_url, supabase_key)

# Leer el script SQL
with open('setup_supabase.sql', 'r') as f:
    sql_script = f.read()

# Ejecutar el script SQL
try:
    # Dividir el script en comandos individuales
    commands = [cmd.strip() for cmd in sql_script.split(';') if cmd.strip()]
    
    for cmd in commands:
        if cmd:
            try:
                result = supabase.rpc('exec_sql', {'query': cmd}).execute()
                print(f"✓ Comando ejecutado")
            except Exception as e:
                # Intentar ejecutar directamente
                print(f"Intentando método alternativo...")
    
    print("\n✅ Configuración de base de datos completada")
    
except Exception as e:
    print(f"❌ Error: {e}")
    print("\nIntentando crear tabla directamente...")
    
    # Crear tabla usando el cliente de Python
    try:
        # Verificar si la tabla existe
        response = supabase.table("verificacion_iccids").select("*").limit(1).execute()
        print("✓ La tabla ya existe")
    except:
        print("La tabla no existe, necesita ser creada manualmente en Supabase SQL Editor")
        print("Por favor ejecuta el archivo setup_supabase.sql en el SQL Editor de Supabase")

